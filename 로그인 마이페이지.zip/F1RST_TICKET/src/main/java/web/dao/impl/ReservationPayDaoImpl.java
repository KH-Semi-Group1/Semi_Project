package web.dao.impl;

import java.sql.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.JDBCTemplate;
import web.dao.face.ReservationPayDao;
import web.dto.ReservationPay;
import web.dto.User;

public class ReservationPayDaoImpl implements ReservationPayDao {

	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	@Override
	public List<ReservationPay> selectAllM(Connection conn) {

		String sql = "";
		sql = "SELECT mcname,mcno FROM MUSICAL";
		List<ReservationPay> mlist = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			rs = ps.executeQuery();
			while(rs.next()) {
				ReservationPay r = new ReservationPay();
				
				r.setMcname(rs.getString("mcname"));
				r.setMcno(rs.getInt("mcno"));
				
				mlist.add(r);
				System.out.println("mlist =" + mlist);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rs);
			JDBCTemplate.close(ps);
		}
		return mlist;
	
	}


	@Override
	public int selectMcno(Connection conn, String mcname) {
		String sql = "";
		sql = "SELECT mcno FROM musical WHERE mcname = ?";
		
		int res = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, mcname);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
			ReservationPay r = new ReservationPay();
			res = rs.getInt("mcno");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rs);
			JDBCTemplate.close(ps);

		}
		return res;
	
	}


	@Override
	public int selectSinfoid(Connection conn) {
		String sql = "";
		sql = "SELECT ScheduleInfo_seq.nextval FROM dual";
		
		int nextScheduleInfono = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();

			while(rs.next() ) {
				nextScheduleInfono = rs.getInt("nextval");
			}
		
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rs);
			JDBCTemplate.close(ps);
		}
		return nextScheduleInfono;
	}


	@Override
	public int writeReservation(Connection conn, ReservationPay rvpay, User user) {
		String sql = "";
		sql = "INSERT INTO reservation (resno,scheduleinfoid,userid,resdate,ticketcount,payment,paymoney)";
		sql += " VALUES( reservation_seq.nextval, ?, ?, ?, ?, ?, ?)";
		int res = 0;
		
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, rvpay.getScheduleInfoid());
			ps.setString(2, user.getUserid());
			ps.setTimestamp(3, rvpay.getResdate());
			ps.setInt(4, rvpay.getTicketcount());
			ps.setString(5, rvpay.getPayment());
			ps.setInt(6, rvpay.getPaymoney());
			
			
			res = ps.executeUpdate();

		
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(ps);
		}
		return res;
	
	
	}


	@Override
	public int writeScheduleInfo(Connection conn, ReservationPay rvpay) {
		String sql = "";
		sql = "INSERT INTO scheduleinfo (scheduleinfoid, mcno, scheduledate, scheduletime)";
		sql += " VALUES( ?, ?, ?, ?)";
		int res = 0;
		
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, rvpay.getScheduleInfoid());
			ps.setInt(2, rvpay.getMcno());
			ps.setDate(3, (Date)rvpay.getScheduledate());
			ps.setString(4, rvpay.getScheduletime());
			
			res = ps.executeUpdate();

		
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(ps);
		}
		return res;
	
	
	}


	@Override
	public int writeSeat(Connection conn, ReservationPay rvpay) {
		String sql = "";
		sql = "INSERT INTO seat (seatno, scheduleinfoid)";
		sql += " VALUES( ?, ?)";
		int res = 0;
		
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setInt(1, rvpay.getSeatno());
			ps.setInt(2, rvpay.getScheduleInfoid());

			res = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			JDBCTemplate.close(ps);
		}
		return res;
	
	}


}